from tkinter import *
import sqlite3
from sqlite3 import Error
from PIL import Image, ImageTk
from tkinter import messagebox

########  VARIABLES  ###################

def pop(e, image, name, cat):
    var_name = StringVar()
    var_order = StringVar()
    var_userid = StringVar()
    var_sc = StringVar()
    var_address = StringVar()
    var_card = StringVar()
    var_conf = StringVar()
    var_contact = StringVar()
    var_city = StringVar()
    var_payment = StringVar()

    def submit():
        messagebox.showinfo('Info', 'Your Order Has been Submitted Successfully !')
        top.destroy()



    top = Toplevel(root)
    top.geometry("800x500+0+0")
    top.configure(background='white')

    head = Label(top, text="Check Out", bg="skyblue", font=("Times", 40, "bold"))
    head.place(x=0, y=0, relwidth=1)

    label_name = Label(top, text="User Name", width=20, bg='white', fg='black', font=("bold", 10))
    label_name.place(x=80, y=130)
    entry = Entry(top, textvar=var_name).place(x=240, y=130)
    label_city = Label(top, text="City", width=20, bg='white', fg='black', font=("bold", 10))
    label_city.place(x=70, y=320)
    entry = Entry(top, textvar=var_city).place(x=240, y=320)
    label_contact = Label(top, text="Contact", width=20, bg='white', fg='black', font=("bold", 10))
    label_contact.place(x=70, y=360)
    entry = Entry(top, textvar=var_contact).place(x=240, y=360)
    label_card = Label(top, text="Credit Card no:", width=20, bg='white', fg='black', font=("bold", 10))
    label_card.place(x=445, y=300)
    entry = Entry(top, textvar=var_card).place(x=590, y=300)
    label_address = Label(top, text="Delivery Address:", width=20, bg='white', fg='black', font=("bold", 10))
    label_address.place(x=420, y=350)
    entry = Entry(top, textvar=var_address).place(x=590, y=350)
    label_sc = Label(top, text="Quantity", bg='white', fg='black', width=20, font=("bold", 10))
    label_sc.place(x=390, y=180)
    entry = Entry(top, textvar=var_sc).place(x=540, y=180)
    label_payment = Label(top, text="Payment", width=20, bg='white', fg='black', font=("bold", 10))
    label_payment.place(x=70, y=230)
    radiobutton = Radiobutton(top, text="Cash online", variable=var_payment, bg='white', fg='black',value='Cash Online').place(x=235, y=230)
    radiobutton = Radiobutton(top, text="Cash on Delivery", variable=var_payment, bg='white', fg='black',value='Cash on Delivery').place(x=320, y=230)
    label_conf = Label(top, text="Confirm order? ", width=21, bg='white', fg='black', font=("bold", 10))
    label_conf.place(x=445, y=230)
    radiobutton = Radiobutton(top, text="Yes", variable=var_conf, bg='white', fg='black', value='Yes').place(x=480, y=260)
    radiobutton = Radiobutton(top, text="No", variable=var_conf, bg='white', fg='black', value='No').place(x=530, y=260)
    button = Button(top, text='Continue', width=20, bg='black', fg='white', command=submit).place(x=340, y=430)


root = Tk()
root.geometry("1600x1200+0+0")
scroll = Scrollbar(root, orient=VERTICAL)
scroll.pack(side=RIGHT, fill=Y)


def func(e):
    pop("e", product[2], product[1], product[0])

head = Label(text = "Galaxy.PK", bg="skyblue",font=("Times" , 40, "bold"))
head.place(x=0, y=0, relwidth=1)

cat1 = LabelFrame(text = "Laptops", bd = 10, padx=10, pady=5, fg="green", font = ("Times",28, "bold"))
cat1.place(x=0, y=80)

size = (200,150)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products")
    lst = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat1)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst.append(i)
        img_lbl = Label(prod_frm, image=lst[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text = product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")
    
except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products")
    lst11 = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat1)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst11.append(i)
        img_lbl = Label(prod_frm, image=lst11[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products")
    lsth = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat1)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lsth.append(i)
        img_lbl = Label(prod_frm, image=lsth[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)


cat2 = LabelFrame(root, text = "Personal Computers", bd = 10, padx=10, pady=5, fg="green", font = ("Times",28, "bold"))
cat2.place(x=0, y=320)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products1")
    lst1 = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat2)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst1.append(i)
        img_lbl = Label(prod_frm, image=lst1[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products1")
    lst111 = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat2)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst111.append(i)
        img_lbl = Label(prod_frm, image=lst111[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products1")
    lst1g = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat2)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst1g.append(i)
        img_lbl = Label(prod_frm, image=lst1g[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)

cat3 = LabelFrame(root, text="Desktop PCs", bd=10, padx=10, pady=5, fg="green", font=("Times", 28, "bold"))
cat3.place(x=0, y=560)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products2")
    lst2t = []
    x = 0
    for i in range(3):
        for product in prods:
            prod_frm = Frame(cat3)
            path = str(product[2])
            img = Image.open(path)
            img = img.resize(size, Image.ANTIALIAS)
            i = ImageTk.PhotoImage(img)
            lst2t.append(i)
            img_lbl = Label(prod_frm, image=lst2t[x])
            x += 1
            img_lbl.pack()
            name = Label(prod_frm, text=product[1])
            name.pack()
            name.bind("<Button-1>", func)
            img_lbl.bind("<Button-1>", func)
            prod_frm.pack(side="left")

except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products2")
    lst2tg = []
    x = 0
    for i in range(3):
        for product in prods:
            prod_frm = Frame(cat3)
            path = str(product[2])
            img = Image.open(path)
            img = img.resize(size, Image.ANTIALIAS)
            i = ImageTk.PhotoImage(img)
            lst2tg.append(i)
            img_lbl = Label(prod_frm, image=lst2tg[x])
            x += 1
            img_lbl.pack()
            name = Label(prod_frm, text=product[1])
            name.pack()
            name.bind("<Button-1>", func)
            img_lbl.bind("<Button-1>", func)
            prod_frm.pack(side="left")

except Error as e:
    print(e)


try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products1")
    lst1x = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat3)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst1x.append(i)
        img_lbl = Label(prod_frm, image=lst1x[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")

except Error as e:
    print(e)


cat4 = LabelFrame(root, text="Other Accessories", bd=10, padx=10, pady=5, fg="green", font=("Times", 28, "bold"))
cat4.place(x=0, y=800)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products3")
    lst3 = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat4)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst3.append(i)
        img_lbl = Label(prod_frm, image=lst3[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")
except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products3")
    lst3x = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat4)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst3x.append(i)
        img_lbl = Label(prod_frm, image=lst3x[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")
except Error as e:
    print(e)

try:
    db = sqlite3.connect("db.db")
    db_cur = db.cursor()
    prods = db_cur.execute("SELECT * from products3")
    lst3xx = []
    x = 0
    for product in prods:
        prod_frm = Frame(cat4)
        path = str(product[2])
        img = Image.open(path)
        img = img.resize(size, Image.ANTIALIAS)
        i = ImageTk.PhotoImage(img)
        lst3xx.append(i)
        img_lbl = Label(prod_frm, image=lst3xx[x])
        x += 1
        img_lbl.pack()
        name = Label(prod_frm, text=product[1])
        name.pack()
        name.bind("<Button-1>", func)
        img_lbl.bind("<Button-1>", func)
        prod_frm.pack(side="left")
except Error as e:
    print(e)


root.mainloop()
